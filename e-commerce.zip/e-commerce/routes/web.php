<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\CouponController;
use App\Http\Controllers\SizeController;
use App\Http\Controllers\ColorController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\BannerController;
use App\Http\Controllers\TopproductController;
use App\Http\Controllers\MenController;
use App\Http\Controllers\WomenController;
use App\Http\Controllers\SportController;
use App\Http\Controllers\ElectronicController;
use App\Http\Controllers\BrandController;
use App\Http\Controllers\PopularController;
use App\Http\Controllers\FeaturedController;
use App\Http\Controllers\LatestController;
use App\Http\Controllers\TestimonialController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\OrderdetailController;
use App\Http\Controllers\FooterController;
use App\Http\Controllers\Front\FrontController;
// use App\Http\Controllers\CustomerreviewController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[FrontController::class,'index']);












Route::get('admin',[AdminController::class,'index']);
Route::post('admin/auth',[AdminController::class,'auth'])->name('admin.auth');

Route::group(['middleware'=>'admin_auth'],function(){
    Route::get('admin/dashboard',[AdminController::class,'dashboard']);

//category page routs starts here
    Route::get('admin/category',[CategoryController::class,'index']);
    Route::get('admin/category/manage_category',[CategoryController::class,'manage_category']);
    Route::get('admin/category/manage_category/{id}',[CategoryController::class,'manage_category']);
    Route::post('admin/category/manage_category_process',[CategoryController::class,'manage_category_process'])->name('category.manage_category_process');
    Route::get('admin/category/delete/{id}',[CategoryController::class,'delete']);
    Route::get('admin/category/status/{status}/{id}',[CategoryController::class,'status']);
//category page routs end here

//coupons page routs starts here
    Route::get('admin/coupon',[CouponController::class,'index']);
    Route::get('admin/coupon/manage_coupon',[CouponController::class,'manage_coupon']);
    Route::get('admin/coupon/manage_coupon/{id}',[CouponController::class,'manage_coupon']);
    Route::post('admin/coupon/manage_coupon_process',[CouponController::class,'manage_coupon_process'])->name('coupon.manage_coupon_process');
    Route::get('admin/coupon/delete/{id}',[CouponController::class,'delete']);
    Route::get('admin/coupon/status/{status}/{id}',[CouponController::class,'status']);
//size page routs end here

//size page routs starts here
    Route::get('admin/size',[SizeController::class,'index']);
    Route::get('admin/size/manage_size',[SizeController::class,'manage_size']);
    Route::get('admin/size/manage_size/{id}',[SizeController::class,'manage_size']);
    Route::post('admin/size/manage_size_process',[SizeController::class,'manage_size_process'])->name('size.manage_size_process');
    Route::get('admin/size/delete/{id}',[SizeController::class,'delete']);
    Route::get('admin/size/status/{status}/{id}',[SizeController::class,'status']);
//size page routs end here

//color page routs starts here
Route::get('admin/color',[ColorController::class,'index']);
Route::get('admin/color/manage_color',[ColorController::class,'manage_color']);
Route::get('admin/color/manage_color/{id}',[ColorController::class,'manage_color']);
Route::post('admin/color/manage_color_process',[ColorController::class,'manage_color_process'])->name('color.manage_color_process');
Route::get('admin/color/delete/{id}',[ColorController::class,'delete']);
Route::get('admin/color/status/{status}/{id}',[ColorController::class,'status']);
//color page routs end here

//Product page routs starts here
Route::get('admin/product/product',[ProductController::class,'index']);
Route::get('admin/product/product/manage_product',[ProductController::class,'manage_product']);
Route::get('admin/product/product/manage_product/{id}',[ProductController::class,'manage_product']);
Route::post('admin/product/product/manage_product_process',[ProductController::class,'manage_product_process'])->name('product.product.manage_product_process');
Route::get('admin/product/product/delete/{id}',[ProductController::class,'delete']);
Route::get('admin/product/product/status/{status}/{id}',[ProductController::class,'status']);
//Product page routs end here

//Banner page routs starts here
Route::get('admin/product/banner/banner',[BannerController::class,'index']);
Route::get('admin/product/banner/banner/manage_banner',[BannerController::class,'manage_banner']);
Route::get('admin/product/banner/banner/manage_banner/{id}',[BannerController::class,'manage_banner']);
Route::post('admin/product/banner/banner/manage_banner_process',[BannerController::class,'manage_banner_process'])->name('product.banner.banner.manage_banner_process');
Route::get('admin/product/banner/banner/delete/{id}',[BannerController::class,'delete']);
Route::get('admin/product/banner/banner/status/{status}/{id}',[BannerController::class,'status']);
//Banner page routs end here

//topproduct page routs starts here
Route::get('admin/product/banner/topproduct',[TopproductController::class,'index']);
Route::get('admin/product/banner/topproduct/manage_topproduct',[TopproductController::class,'manage_topproduct']);
Route::get('admin/product/banner/topproduct/manage_topproduct/{id}',[TopproductController::class,'manage_topproduct']);
Route::post('admin/product/banner/topproduct/manage_topproduct_process',[TopproductController::class,'manage_topproduct_process'])->name('product.banner.topproduct.manage_topproduct_process');
Route::get('admin/product/banner/topproduct/delete/{id}',[TopproductController::class,'delete']);
Route::get('admin/product/banner/topproduct/status/{status}/{id}',[TopproductController::class,'status']);
//topproduct page routs end here

//Men page routs starts here
Route::get('admin/product/banner/men',[MenController::class,'index']);
Route::get('admin/product/banner/men/manage_men',[MenController::class,'manage_men']);
Route::get('admin/product/banner/men/manage_men/{id}',[MenController::class,'manage_men']);
Route::post('admin/product/banner/men/manage_men_process',[MenController::class,'manage_men_process'])->name('product.banner.men.manage_men_process');
Route::get('admin/product/banner/men/delete/{id}',[MenController::class,'delete']);
Route::get('admin/product/banner/men/status/{status}/{id}',[MenController::class,'status']);
//Men page routs end here

//Women page routs starts here
Route::get('admin/product/banner/women',[WomenController::class,'index']);
Route::get('admin/product/banner/women/manage_women',[WomenController::class,'manage_women']);
Route::get('admin/product/banner/women/manage_women/{id}',[WomenController::class,'manage_women']);
Route::post('admin/product/banner/women/manage_women_process',[WomenController::class,'manage_women_process'])->name('product.banner.women.manage_women_process');
Route::get('admin/product/banner/women/delete/{id}',[WomenController::class,'delete']);
Route::get('admin/product/banner/women/status/{status}/{id}',[WomenController::class,'status']);
//Women page routs end here

//Sport page routs starts here
Route::get('admin/product/banner/sport',[SportController::class,'index']);
Route::get('admin/product/banner/sport/manage_sport',[SportController::class,'manage_sport']);
Route::get('admin/product/banner/sport/manage_sport/{id}',[SportController::class,'manage_sport']);
Route::post('admin/product/banner/sport/manage_sport_process',[SportController::class,'manage_sport_process'])->name('product.banner.sport.manage_sport_process');
Route::get('admin/product/banner/sport/delete/{id}',[SportController::class,'delete']);
Route::get('admin/product/banner/sport/status/{status}/{id}',[SportController::class,'status']);
//Sport page routs end here

//Electronics page routs starts here
Route::get('admin/product/banner/electronic',[ElectronicController::class,'index']);
Route::get('admin/product/banner/electronic/manage_electronic',[ElectronicController::class,'manage_electronic']);
Route::get('admin/product/banner/electronic/manage_electronic/{id}',[ElectronicController::class,'manage_electronic']);
Route::post('admin/product/banner/electronic/manage_electronic_process',[ElectronicController::class,'manage_electronic_process'])->name('product.banner.electronic.manage_electronic_process');
Route::get('admin/product/banner/electronic/delete/{id}',[ElectronicController::class,'delete']);
Route::get('admin/product/banner/electronic/status/{status}/{id}',[ElectronicController::class,'status']);
//Electronics page routs end here

//brands page routs starts here
Route::get('admin/product/banner/brand',[BrandController::class,'index']);
Route::get('admin/product/banner/brand/manage_brand',[BrandController::class,'manage_brand']);
Route::get('admin/product/banner/brand/manage_brand/{id}',[BrandController::class,'manage_brand']);
Route::post('admin/product/banner/brand/manage_brand_process',[BrandController::class,'manage_brand_process'])->name('product.banner.brand.manage_brand_process');
Route::get('admin/product/banner/brand/delete/{id}',[BrandController::class,'delete']);
Route::get('admin/product/banner/brand/status/{status}/{id}',[BrandController::class,'status']);
//brands page routs end here

//Popular page routs starts here
Route::get('admin/product/banner/popular',[PopularController::class,'index']);
Route::get('admin/product/banner/popular/manage_popular',[PopularController::class,'manage_popular']);
Route::get('admin/product/banner/popular/manage_popular/{id}',[PopularController::class,'manage_popular']);
Route::post('admin/product/banner/popular/manage_popular_process',[PopularController::class,'manage_popular_process'])->name('product.banner.popular.manage_popular_process');
Route::get('admin/product/banner/popular/delete/{id}',[PopularController::class,'delete']);
Route::get('admin/product/banner/popular/status/{status}/{id}',[PopularController::class,'status']);
//Popular page routs end here

//Featured page routs starts here
Route::get('admin/product/banner/featured',[FeaturedController::class,'index']);
Route::get('admin/product/banner/featured/manage_featured',[FeaturedController::class,'manage_featured']);
Route::get('admin/product/banner/featured/manage_featured/{id}',[FeaturedController::class,'manage_featured']);
Route::post('admin/product/banner/featured/manage_featured_process',[FeaturedController::class,'manage_featured_process'])->name('product.banner.featured.manage_featured_process');
Route::get('admin/product/banner/featured/delete/{id}',[FeaturedController::class,'delete']);
Route::get('admin/product/banner/featured/status/{status}/{id}',[FeaturedController::class,'status']);
//Featured page routs end here

//Latest page routs starts here
Route::get('admin/product/banner/latest',[LatestController::class,'index']);
Route::get('admin/product/banner/latest/manage_latest',[LatestController::class,'manage_latest']);
Route::get('admin/product/banner/latest/manage_latest/{id}',[LatestController::class,'manage_latest']);
Route::post('admin/product/banner/latest/manage_latest_process',[LatestController::class,'manage_latest_process'])->name('product.banner.latest.manage_latest_process');
Route::get('admin/product/banner/latest/delete/{id}',[LatestController::class,'delete']);
Route::get('admin/product/banner/latest/status/{status}/{id}',[LatestController::class,'status']);
//Latest page routs end here

//Testimonial page routs starts here
Route::get('admin/product/banner/testimonial',[TestimonialController::class,'index']);
Route::get('admin/product/banner/testimonial/manage_testimonial',[TestimonialController::class,'manage_testimonial']);
Route::get('admin/product/banner/testimonial/manage_testimonial/{id}',[TestimonialController::class,'manage_testimonial']);
Route::post('admin/product/banner/testimonial/manage_testimonial_process',[TestimonialController::class,'manage_testimonial_process'])->name('product.banner.testimonial.manage_testimonial_process');
Route::get('admin/product/banner/testimonial/delete/{id}',[TestimonialController::class,'delete']);
Route::get('admin/product/banner/testimonial/status/{status}/{id}',[TestimonialController::class,'status']);
//Testimonial page routs end here

//Blog page routs starts here
Route::get('admin/product/banner/blog',[BlogController::class,'index']);
Route::get('admin/product/banner/blog/manage_blog',[BlogController::class,'manage_blog']);
Route::get('admin/product/banner/blog/manage_blog/{id}',[BlogController::class,'manage_blog']);
Route::post('admin/product/banner/blog/manage_blog_process',[BlogController::class,'manage_blog_process'])->name('product.banner.blog.manage_blog_process');
Route::get('admin/product/banner/blog/delete/{id}',[BlogController::class,'delete']);
Route::get('admin/product/banner/blog/status/{status}/{id}',[BlogController::class,'status']);
//Blog page routs end here


//Order-details page routs starts here
Route::get('admin/orderdetail',[OrderdetailController::class,'index']);
Route::get('admin/orderdetail/manage_orderdetail',[OrderdetailController::class,'manage_orderdetail']);
Route::get('admin/orderdetail/manage_orderdetail/{id}',[OrderdetailController::class,'manage_orderdetail']);
Route::post('admin/orderdetail/manage_orderdetail_process',[OrderdetailController::class,'manage_orderdetail_process'])->name('orderdetail.manage_orderdetail_process');
Route::get('admin/orderdetail/delete/{id}',[OrderdetailController::class,'delete']);
Route::get('admin/orderdetail/status/{status}/{id}',[OrderdetailController::class,'status']);
//Order-details page routs end here

//Footer page routs starts here
Route::get('admin/footer',[FooterController::class,'index']);
Route::get('admin/footer/manage_footer',[FooterController::class,'manage_footer']);
Route::get('admin/footer/manage_footer/{id}',[FooterController::class,'manage_footer']);
Route::post('admin/footer/manage_footer_process',[FooterController::class,'manage_footer_process'])->name('footer.manage_footer_process');
Route::get('admin/footer/delete/{id}',[FooterController::class,'delete']);
Route::get('admin/footer/status/{status}/{id}',[FooterController::class,'status']);
//Footer page routs end here


//Custumer review page routs starts here
// Route::get('/admin/customerreview',[CustomerreviewController::class,'index']);
Route::get('admin/customerreview', function () {
    return view('admin/customerreview');
});
//Custumer review page routs end here


    Route::get('admin/logout', function () {
        session()->forget('ADMIN_LOGIN');
        session()->forget('ADMIN_ID');
        session()->flash('error','Logout Successfully');
        return redirect('admin');
    });
});


@extends('admin/layout')
@section('page_title','Manage Orderdetail')
@section('container')


<div class="row m-t-30">
        <div class="col-md-6 col-sm-12 offset-3">
        
        <div class="card">
            
           
            <div class="card-body">
               
                <form action="{{route('orderdetail.manage_orderdetail_process')}}" enctype="multipart/form-data" method="post" style="padding:30px;">
                <h1 class="mb10">Manage Orderdetail</h1>
                    <a href="{{url('admin/orderdetail')}}">
                        <button type="button" class="btn btn-success"> Back</button><br><br><br>
                    </a>
                @csrf    
                <div class="form-group">
                        <label for="Customer_name" class="control-label mb-1">Customer Name</label>
                       <input id="Customer_name" value="{{$Customer_name}}" name="Customer_name" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                       @error('Customer_name')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>
                <div class="form-group">
                        <label for="Address" class="control-label mb-1">Address</label>
                       <input id="Address" value="{{$Address}}" name="Address" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                       @error('Address')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>
                <div class="form-group">
                        <label for="Mobile" class="control-label mb-1">Mobile</label>
                       <input id="Mobile" value="{{$Mobile}}" name="Mobile" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                       @error('Mobile')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>
                <div class="form-group">
                        <label for="product_name" class="control-label mb-1">product name</label>
                       <input id="product_name" value="{{$product_name}}" name="product_name" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                       @error('product_name')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>
                <div class="form-group">
                        <label for="price" class="control-label mb-1">Price</label>
                       <input id="price" value="{{$price}}" name="price" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                       @error('price')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>
                    <div class="form-group">
                        <label for="image" class="control-label mb-1">Image</label>
                        <input id="image" value="{{$image}}" name="image" type="file" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        @error('image')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div> 
                    <div class="form-group">
                        <select value="{{$payment_method}}" name="payment_method" class="col-lg-12 form-select form-select-lg mb-6" aria-label=".form-select-lg example">
                            <option selected>payment_method</option>
                            <option value="Cash On Delivery">Cash On Delivery</option>
                            <option value="Debit Card">Debit Card</option>
                            <option value="Credit Card">Credit Card</option>
                            <option value="UPI">UPI</option>
                        </select>
                    </div><br>
                    <div class="col-lg-4 offset-4">
                        <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">Submit</button>
                    </div>
                    <input type="hidden" name="id" value="{{$id}}"/>
                </form>
            </div>
        </div>
        </div>
    </div>


@endsection
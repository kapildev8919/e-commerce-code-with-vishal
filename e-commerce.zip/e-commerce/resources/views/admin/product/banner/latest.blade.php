@extends('admin/layout')
@section('page_title','Latest')
@section('product_select','active')
@section('container')



<div>
<h1 class="" align=center>latest Product</h1>
<h5>{{session('name')}}</h5>
<a href="{{url('admin/product/banner/latest/manage_latest')}}">
    <button type="button" class="btn btn-success"> Add latest Product</button>
</a>
<div class="row m-t-30">
        <div class="col-md-12 col-sm-12">
            <!-- DATA TABLE-->
            <div class="table-responsive m-b-40">
                <table class="table table-borderless table-data3">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Product Name</th>
                            <th>Price</th>
                            <th>Discount</th>
                            <th>Image</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($data as $list)
                        <tr>
                            <td>{{$list->id}}</td>
                            <td>{{$list->product_name}}</a>
                            <td>{{$list->price}}</td>
                            <td>{{$list->discount}}</td>
                            <td><a href="{{asset('/img/'.$list->image)}}"><img src="{{asset('/img/'.$list->image)}}" alt=""  style="width: 100px; height:100px;" /></a></td>
                            <td>{{$list->description}}</td>
                            <td>{{$list->status}}</td>
                            <td>
                                <a href="{{url('admin/product/banner/latest/manage_latest/')}}/{{$list->id}}">
                                    <button type="button" class="btn btn-info">Edit</button>
                                </a>
                                @if($list->status==1)
                                <a href="{{url('admin/product/banner/latest/status/0')}}/{{$list->id}}">
                                    <button type="button" class="btn btn-success">
                                        <i class="fa fa-check" aria-hidden="true"></i>
                                    </button>
                                </a>
                                @elseif($list->status==0)
                                <a href="{{url('admin/product/banner/latest/status/1')}}/{{$list->id}}">
                                    <button type="button" class="btn btn-warning">
                                        <i class="fa fa-times" aria-hidden="true"></i>
                                    </button>
                                </a>
                                @endif
                                <a href="{{url('admin/product/banner/latest/delete/')}}/{{$list->id}}">
                                    <button type="button" class="btn btn-danger">Delete</button>
                                </a>
                            </td>
                        </tr>
                        @endforeach
                        
                    </tbody>
                </table>
            </div>
            <!-- END DATA TABLE-->
        </div>
    </div>

    @if(session()->has('message'))
<script>
       
iziToast.info({
    timeout: 5000,
    overlay: false,
    displayMode: 'once',
    id: 'inputs',
    zindex: 1,
    title: "<h3 class='text-danger'>Alert-:</h3>",
    message: "<h3 class='text-success'>{{session('message')}}</h3>",
    position: 'center',
    drag: true,
   
});
       
    </script>
    @endif



@endsection
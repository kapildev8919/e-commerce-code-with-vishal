@extends('admin/layout')
@section('page_title','Product')
@section('product_select','active')
@section('container')


<div>
<h1 class="" align=center>Product</h1>
<a href="{{url('admin/product/product/manage_product')}}">
    <button type="button" class="btn btn-success"> Add Product</button>
</a>
<div class="row m-t-30">
        <div class="col-md-12 col-sm-12">
            <!-- DATA TABLE-->
            <div class="table-responsive m-b-40">
                <table class="table table-borderless table-data3">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Product Name</th>
                            
                            <th>Category</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($data as $list)
                        <tr>
                            <td>{{$list->id}}</td>
                            <!-- <td><a href="{{url('admin/product/banner/banner')}}">{{$list->Product_Name}}</a></td> -->
                            <td><a href="{{$list->url}}">{{$list->Product_Name}}</a></td>
                            <!-- <td>{{$list->url}}</td> -->
                            
                            
                            <td>{{$list->Category}}</td>
                            <td>
                                <a href="{{url('admin/product/product/manage_product/')}}/{{$list->id}}">
                                    <button type="button" class="btn btn-info">Edit</button>
                                </a>
                                @if($list->status==1)
                                <a href="{{url('admin/product/product/status/0')}}/{{$list->id}}">
                                    <button type="button" class="btn btn-success">
                                        <i class="fa fa-check" aria-hidden="true"></i>
                                    </button>
                                </a>
                                @elseif($list->status==0)
                                <a href="{{url('admin/product/product/status/1')}}/{{$list->id}}">
                                    <button type="button" class="btn btn-warning">
                                        <i class="fa fa-times" aria-hidden="true"></i>
                                    </button>
                                </a>
                                @endif
                                <a href="{{url('admin/product/product/delete/')}}/{{$list->id}}">
                                    <button type="button" class="btn btn-danger">Delete</button>
                                </a>
                            </td>
                        </tr>
                        @endforeach
                        
                    </tbody>
                </table>
            </div>
            <!-- END DATA TABLE-->
        </div>
    </div>

    @if(session()->has('message'))
<script>
       
iziToast.info({
    timeout: 5000,
    overlay: false,
    displayMode: 'once',
    id: 'inputs',
    zindex: 1,
    title: "<h3 class='text-danger'>Alert-:</h3>",
    message: "<h3 class='text-success'>{{session('message')}}</h3>",
    position: 'center',
    drag: true,
    
});
       
    </script>
    @endif


@endsection
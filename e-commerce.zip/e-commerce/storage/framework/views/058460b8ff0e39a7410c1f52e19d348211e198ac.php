
<?php $__env->startSection('page_title','Manage Category'); ?>
<?php $__env->startSection('container'); ?>


<div class="row m-t-30">
        <div class="col-md-6 col-sm-12 offset-3">
        
        <div class="card">
            <!-- <div class="card-header">Manage category</div> -->
           
            <div class="card-body">
                <!-- <div class="card-title">
                    <h3 class="text-center title-2">Pay Invoice</h3>
                </div> -->
                <!-- <hr> -->
                <form action="<?php echo e(route('category.manage_category_process')); ?>" enctype="multipart/form-data" method="post" style="padding:30px;">
                <h1 class="mb10">Manage Category</h1>
<a href="<?php echo e(url('admin/category')); ?>">
    <button type="button" class="btn btn-success"> Back</button><br><br><br>
</a>
                <?php echo csrf_field(); ?>    
                <div class="form-group">
                        <label for="Category_name" class="control-label mb-1">Category Name</label>
                       <input id="Category_name" value="<?php echo e($category_name); ?>" name="category_name" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                       <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="Category_slug" class="control-label mb-1">Category Slug</label>
                        <input id="Category_slug" value="<?php echo e($category_slug); ?>" name="category_slug" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        <?php $__errorArgs = ['category_slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>  
                    <div class="form-group">
                        <label for="Image" class="control-label mb-1">image</label>
                        <input id="Image" value="<?php echo e($image); ?>" name="image" type="file" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>  
                    <div class="col-lg-4 offset-4">
                        <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">Submit</button>
                    </div>
                    <input type="hidden" name="id" value="<?php echo e($id); ?>"/>
                </form>
            </div>
        </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\new-project\e-commerce\resources\views/admin/manage_category.blade.php ENDPATH**/ ?>
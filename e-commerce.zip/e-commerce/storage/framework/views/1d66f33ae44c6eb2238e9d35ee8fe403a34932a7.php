<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Title Page-->
    <title><?php echo $__env->yieldContent('page_title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/iziToast.min.css')); ?>">
    <script src="<?php echo e(asset('admin_assets/js/iziToast.min.js')); ?>" type="text/javascript"></script>
    <!-- Fontfaces CSS-->
    <link href="<?php echo e(asset('admin_assets/css/font-face.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/font-awesome-4.7/css/font-awesome.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/font-awesome-5/css/fontawesome-all.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/mdi-font/css/material-design-iconic-font.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="<?php echo e(asset('admin_assets/vendor/bootstrap-4.1/bootstrap.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="<?php echo e(asset('admin_assets/vendor/animsition/animsition.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/wow/animate.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/css-hamburgers/hamburgers.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/slick/slick.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/select2/select2.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/perfect-scrollbar/perfect-scrollbar.css')); ?>" rel="stylesheet" media="all">



    <script src="iziToast.min.js" type="text/javascript"></script>
    <!-- Main CSS-->
    <link href="<?php echo e(asset('admin_assets/css/theme.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/css/reviewtheme.css')); ?>" rel="stylesheet" media="all">
<style>
    hr{margin-top:5px;margin-bottom:5px; background: grey;opacity:.3;}
</style>
</head>

<body>
   
<div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                            <img src="images/icon/logo.png" alt="CoolAdmin" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                    <li class="has-sub">
                            <a href="<?php echo e(url('admin/dashboard')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('admin/category')); ?>">
                            <i class="fa fa-list-alt" aria-hidden="true"></i>Category</a>
                        </li>  
                        <li>
                            <a href="<?php echo e(url('admin/coupon')); ?>">
                            <i class="fa fa-list-alt" aria-hidden="true"></i>Coupon</a>
                        </li>   
                    </ul>
                </div>
            </nav>
        </header>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block" style=" overflow:visible;">
            <div class="logo" style="width:100%;">
                <a href="#" style="width:50%;margin-left:10%;">
                    <img src="<?php echo e(asset('admin_assets/images/icon/logo1111.png')); ?>" alt="Cool Admin" / style="width:100%;">
                </a>
            </div> <!--<hr style="background: white;margin-top:0;padding-top:0; width:70%;"> -->
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                    <li class="<?php echo $__env->yieldContent('dashboard_select'); ?>">
                            <a href="<?php echo e(url('admin/dashboard')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li><hr>
                        <li class="<?php echo $__env->yieldContent('category_select'); ?>">
                            <a href="<?php echo e(url('admin/category')); ?>">
                            <i class="fas fa-list"></i>Category</a>
                        </li>   <hr>
                        <li class="<?php echo $__env->yieldContent('coupon_select'); ?>">
                            <a href="<?php echo e(url('admin/coupon')); ?>">
                            <i class="fas fa-tag"></i>Coupon</a>
                        </li>  <hr>
                        <li class="<?php echo $__env->yieldContent('size_select'); ?>">
                            <a href="<?php echo e(url('admin/size')); ?>">
                            <i class="fas fa-window-maximize" aria-hidden="true"></i>Size</a>
                        </li>   <hr>
                        <li class="<?php echo $__env->yieldContent('color_select'); ?>">
                            <a href="<?php echo e(url('admin/color')); ?>">
                            <i class="fas fa-paint-brush"></i>Color</a>
                        </li>   <hr>
                        <li class="<?php echo $__env->yieldContent('product_select'); ?>">
                            <a href="<?php echo e(url('admin/product/product')); ?>">
                            <i class="fas fa-sliders"></i>Product</a>
                        </li>   <hr> 
                        <li class="<?php echo $__env->yieldContent('orderdetail_select'); ?>">
                            <a href="<?php echo e(url('admin/orderdetail')); ?>">
                            <i class="fas fa-cart-plus"></i>Order Details</a>
                        </li>   <hr> 
                        <li class="<?php echo $__env->yieldContent('customerreview_select'); ?>">
                            <a href="<?php echo e(url('admin/customerreview')); ?>">
                            <span class="fa fa-star checked"></span>
                            Customer Reviews</a>
                        </li>   <hr>
                        <li class="<?php echo $__env->yieldContent('footer_select'); ?>">
                            <a href="<?php echo e(url('admin/footer')); ?>">
                            <i class="fa fa-handshake-o" aria-hidden="true"></i>Footer</a>
                        </li> 
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop" style="background: rgba(0, 0, 0, 1);">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <form class="form-header" action="" method="POST">
                                
                            </form>
                            <div class="header-button">
                                <div class="noti-wrap">    
                                </div>
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="<?php echo e(asset('admin_assets/images/icon/avatar-01.jpg')); ?>" alt="John Doe" />
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#">Welcome Admin</a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            
                                            <div class="account-dropdown__body">
                                                <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-account"></i>Account</a>
                                                </div>
                                                <!-- <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-settings"></i>Setting</a>
                                                </div>
                                                <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-money-box"></i>Billing</a>
                                                </div> -->
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href="<?php echo e(url('admin/logout')); ?>">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- END HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                    <?php $__env->startSection('container'); ?>
                    <?php echo $__env->yieldSection(); ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- END PAGE CONTAINER-->
    </div>
    <script src="iziToast.min.js" type="text/javascript"></script>
   
   
    <script src="<?php echo e(asset('admin_assets/vendor/jquery-3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/vendor/bootstrap-4.1/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/vendor/bootstrap-4.1/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/vendor/wow/wow.min.js')); ?>"></script>

<!-- Vendor JS       -->
<script src="<?php echo e(asset('admin_assets/vendor/slick/slick.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('admin_assets/vendor/wow/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/vendor/animsition/animsition.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('admin_assets/vendor/counter-up/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/vendor/counter-up/jquery.counterup.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('admin_assets/vendor/circle-progress/circle-progress.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/vendor/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/vendor/chartjs/Chart.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/vendor/select2/select2.min.js')); ?>">
    </script>

    <script src="<?php echo e(asset('admin_assets/js/main.js')); ?>"></script>

</body>

</html>
<!-- end document--><?php /**PATH C:\wamp64\www\new-project\e-commerce\resources\views/admin/layout.blade.php ENDPATH**/ ?>
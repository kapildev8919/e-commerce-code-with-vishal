
<?php $__env->startSection('page_title','Manage Product'); ?>
<?php $__env->startSection('container'); ?>


<div class="row m-t-30">
        <div class="col-md-6 col-sm-12 offset-3">
        
        <div class="card">
            
           
            <div class="card-body">
               
                <form action="<?php echo e(route('product.product.manage_product_process')); ?>" method="post" style="padding:30px;">
                <h1 class="mb10">Manage Product</h1>
<a href="<?php echo e(url('admin/product/product')); ?>">
    <button type="button" class="btn btn-success"> Back</button><br><br><br>
</a>
                <?php echo csrf_field(); ?>    
                <div class="form-group">
                        <label for="Product_Name" class="control-label mb-1">Product Name</label>
                       <input id="Product_Name" value="<?php echo e($Product_Name); ?>" name="Product_Name" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                       <?php $__errorArgs = ['Product_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="Category" class="control-label mb-1">Category</label>
                        <input id="Category" value="<?php echo e($Category); ?>" name="Category" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        <?php $__errorArgs = ['Category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>  
                    <div class="col-lg-4 offset-4">
                        <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">Submit</button>
                    </div>
                    <input type="hidden" name="id" value="<?php echo e($id); ?>"/>
                </form>
            </div>
        </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\new-project\e-commerce\resources\views/admin/product/manage_product.blade.php ENDPATH**/ ?>
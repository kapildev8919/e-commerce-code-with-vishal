<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Title Page-->
    <title>Login</title>

    <!-- Fontfaces CSS-->
    <link href="<?php echo e(asset('admin_assets/css/font-face.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/font-awesome-4.7/css/font-awesome.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/font-awesome-5/css/fontawesome-all.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/mdi-font/css/material-design-iconic-font.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="<?php echo e(asset('admin_assets/vendor/bootstrap-4.1/bootstrap.min.css')); ?>" rel="stylesheet" media="all">

   
    <!-- Main CSS-->
    <link href="<?php echo e(asset('admin_assets/css/theme.css')); ?>" rel="stylesheet" media="all">

</head>

<body class="animsition" style="background: black;">
    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container-fluid" style="background: black;">
                <div class="login-wrap">
                    <div class="login-content col-lg-8 offset-2" style="background:rgba(111, 230, 210, 0.8);border:1px solid black;border-radius:10px;">
                        <div class="login-logo col-lg-5 col-md-5 col-sm-5 offset-3">
                            <!-- <?php echo e(Config::get('constants.site_name')); ?> -->
                            <a href="#">
                                <img src="<?php echo e(asset('admin_assets/images/icon/logo1111.png')); ?>" alt="CoolAdmin"><hr style=" background:black;">
                            </a>
                        </div>
                        <div class="login-form" style="padding-left:10%;padding-right:10%;">
                            <form action="<?php echo e(route('admin.auth')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <!-- <label>Email Address</label> -->
                                    <input class="form-control" type="email" name="email" placeholder="Email" required style="color:black; border-radius:50px 0 50px 0;padding-left:10%;"><br>
                                </div>
                                <div class="form-group">
                                    <!-- <label>Password</label> -->
                                    <input class="form-control" type="password" name="password" placeholder="Password" required style="color:black; border-radius:50px 0 50px 0;padding-left:10%;"><br>
                                </div>
                                
                                <button class="btn btn-dark au-btn--blue" type="submit" style="color:#fff; border:0px;font-weight:600;width:50%;margin-left:25%;">sign in</button>
                                <br>
                                
                                   <h4 class="text-danger" style="margin-top:10px;padding:0px 0px 0px 0px;"><?php echo e(session('error')); ?></h4>
                                
                            </form>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="<?php echo e(asset('admin_assets/vendor/jquery-3.2.1.min.js')); ?>"></script>
    <!-- Bootstrap JS-->
    <script src="<?php echo e(asset('admin_assets/vendor/bootstrap-4.1/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/vendor/bootstrap-4.1/bootstrap.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('admin_assets/vendor/wow/wow.min.js')); ?>"></script>
    

    <!-- Main JS-->
    <script src="<?php echo e(asset('admin_assets/js/main.js')); ?>"></script>

</body>

</html>
<!-- end document--><?php /**PATH C:\wamp64\www\new-project\e-commerce\resources\views/admin/login.blade.php ENDPATH**/ ?>
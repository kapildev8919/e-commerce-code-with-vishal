

<?php $__env->startSection('dashboard_select','active'); ?>
<?php $__env->startSection('container'); ?>





<div class="main-content" style="padding-top:0;">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="au-card m-b-30" style="background: rgba(111, 230, 210, 0.5);">
                                    <div class="au-card-inner">
                                        <h3 class="title-2 m-b-40">Yearly Sales</h3>
                                        <canvas id="sales-chart"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="au-card m-b-30" style="background: rgba(111, 230, 210, 0.5);">
                                    <div class="au-card-inner">
                                        <h3 class="title-2 m-b-40">Team Commits</h3>
                                        <canvas id="team-chart"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="au-card m-b-30" style="background: rgba(111, 230, 210, 0.5);">
                                    <div class="au-card-inner">
                                        <h3 class="title-2 m-b-40">Bar chart</h3>
                                        <canvas id="barChart"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="au-card m-b-30" style="background: rgba(111, 230, 210, 0.5);">
                                    <div class="au-card-inner">
                                        <h3 class="title-2 m-b-40">Rader chart</h3>
                                        <canvas id="radarChart"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="au-card m-b-30" style="background: rgba(111, 230, 210, 0.5);">
                                    <div class="au-card-inner">
                                        <h3 class="title-2 m-b-40">Line Chart</h3>
                                        <canvas id="lineChart"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="au-card m-b-30" style="background: rgba(111, 230, 210, 0.5);">
                                    <div class="au-card-inner">
                                        <h3 class="title-2 m-b-40">Doughut Chart</h3>
                                        <canvas id="doughutChart"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="au-card m-b-30" style="background: rgba(111, 230, 210, 0.5);">
                                    <div class="au-card-inner">
                                        <h3 class="title-2 m-b-40">Pie Chart</h3>
                                        <canvas id="pieChart"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="au-card m-b-30" style="background: rgba(111, 230, 210, 0.5);">
                                    <div class="au-card-inner">
                                        <h3 class="title-2 m-b-40">Polar Chart</h3>
                                        <canvas id="polarChart"></canvas>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        
                    </div>
                </div>
            </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\new-project\e-commerce\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
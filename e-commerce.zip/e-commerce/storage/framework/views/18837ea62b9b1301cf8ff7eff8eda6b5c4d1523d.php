
<?php $__env->startSection('page_title','Manage Footer'); ?>
<?php $__env->startSection('container'); ?>


<div class="row m-t-30">
        <div class="col-md-6 col-sm-12 offset-3">
        
        <div class="card">
           
           
            <div class="card-body">
                
                <form action="<?php echo e(route('footer.manage_footer_process')); ?>" method="post" style="padding:30px;">
                <h1 class="mb10">Manage Footer</h1>
<a href="<?php echo e(url('admin/footer')); ?>">
    <button type="button" class="btn btn-success"> Back</button><br><br><br>
</a>
                <?php echo csrf_field(); ?>    
                <div class="form-group">
                        <label for="menu" class="control-label mb-1">menu</label>
                       <input id="menu" value="<?php echo e($menu); ?>" name="menu" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                       <?php $__errorArgs = ['menu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="discount" class="control-label mb-1">discount</label>
                        <input id="discount" value="<?php echo e($discount); ?>" name="discount" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="offer" class="control-label mb-1">offer</label>
                        <input id="offer" value="<?php echo e($offer); ?>" name="offer" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        <?php $__errorArgs = ['offer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>  
                    <div class="form-group">
                        <label for="site_map" class="control-label mb-1">site_map</label>
                        <input id="site_map" value="<?php echo e($site_map); ?>" name="site_map" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        <?php $__errorArgs = ['site_map'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>  
                    <div class="form-group">
                        <label for="suppliers" class="control-label mb-1">suppliers</label>
                        <input id="suppliers" value="<?php echo e($suppliers); ?>" name="suppliers" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        <?php $__errorArgs = ['suppliers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>  
                    <div class="form-group">
                        <label for="faq" class="control-label mb-1">faq</label>
                        <input id="faq" value="<?php echo e($faq); ?>" name="faq" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        <?php $__errorArgs = ['faq'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>  
                    <div class="form-group">
                        <label for="address" class="control-label mb-1">address</label>
                        <input id="address" value="<?php echo e($address); ?>" name="address" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>    
                    <div class="form-group">
                        <label for="mobile" class="control-label mb-1">mobile</label>
                        <input id="mobile" value="<?php echo e($mobile); ?>" name="mobile" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>  
                    <div class="form-group">
                        <label for="email" class="control-label mb-1">email</label>
                        <input id="email" value="<?php echo e($email); ?>" name="email" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>  
                    <div class="form-group">
                        <label for="links" class="control-label mb-1">links</label>
                        <input id="links" value="<?php echo e($links); ?>" name="links" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        <?php $__errorArgs = ['links'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>  
                    <div class="col-lg-4 offset-4">
                        <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">Submit</button>
                    </div>
                    <input type="hidden" name="id" value="<?php echo e($id); ?>"/>
                </form>
            </div>
        </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\new-project\e-commerce\resources\views/admin/manage_footer.blade.php ENDPATH**/ ?>

<?php $__env->startSection('page_title','Manage Featured Product'); ?>
<?php $__env->startSection('container'); ?>


<div class="row m-t-30">
        <div class="col-md-6 col-sm-12 offset-3">
        
        <div class="card">
            
           
            <div class="card-body">
               
                <form action="<?php echo e(route('product.banner.featured.manage_featured_process')); ?>" method="post" enctype="multipart/form-data" style="padding:30px;">
                <h1 class="mb10">Manage Featured</h1>
<a href="<?php echo e(url('admin/product/banner/featured')); ?>">
    <button type="button" class="btn btn-success"> Back</button><br><br><br>
</a>
                <?php echo csrf_field(); ?>    
                <div class="form-group">
                        <label for="product_Name" class="control-label mb-1">Product Name</label>
                       <input id="product_Name" value="<?php echo e($product_name); ?>" name="product_name" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                       <?php $__errorArgs = ['Product_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="price" class="control-label mb-1">price</label>
                       <input id="price" value="<?php echo e($price); ?>" name="price" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                       <?php $__errorArgs = ['Price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="Discount" class="control-label mb-1">Discount</label>
                        <input id="Discount" value="<?php echo e($discount); ?>" name="discount" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        <?php $__errorArgs = ['Discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>  
                    <div class="form-group">
                        <label for="Image" class="control-label mb-1">Image</label>
                        <input id="Image" value="<?php echo e($image); ?>" name="image" type="file" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        <?php $__errorArgs = ['Image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div> 
                    <div class="form-group">
                        <label for="Description" class="control-label mb-1">Description</label>
                        <input id="Description" value="<?php echo e($description); ?>" name="description" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        <?php $__errorArgs = ['Description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-lg-4 offset-4">
                        <button id="payfeaturedt-button" type="submit" class="btn btn-lg btn-info btn-block">Submit</button>
                    </div>
                    <input type="hidden" name="id" value="<?php echo e($id); ?>"/>
                </form>
            </div>
        </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\new-project\e-commerce\resources\views/admin/product/banner/manage_featured.blade.php ENDPATH**/ ?>
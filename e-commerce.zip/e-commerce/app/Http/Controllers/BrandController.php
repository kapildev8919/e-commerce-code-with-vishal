<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use Illuminate\Http\Request;

class BrandController extends Controller
{
    public function index()
    {
        $result['data']=Brand::all();
        return view('admin/product/banner/brand',$result);
    }
    
    public function manage_brand(Request $request,$id='')
    {
        if($id>0){
            $arr= Brand::where(['id'=>$id])->get();
            
            $result['product_name']=$arr['0']->product_name; 
           
            $result['image']=$arr['0']->image; 
            $result['description']=$arr['0']->description; 
            $result['status']=$arr['0']->status; 
            $result['id']=$arr['0']->id; 
        }
        else{
            $result['product_name']=''; 
           
            $result['image']=''; 
            $result['description']=''; 
            $result['status']=''; 
            $result['id']=''; 
        }
        
        return view('admin/product/banner/manage_brand',$result);
    }

    public function manage_brand_process(Request $request)
    {
        // return $request->post();
        $request->validate([
            'product_name'=>'required',
            
            'image'=>'required',
            'description'=>'required',
        ]);

       
        if($request->post('id')>0)
        {
            $model=Brand::find($request->post('id'));
            $msg ="Brand Updated";
        }
        else{
            $model=new Brand();
            $msg ="Brand Inserted";
        }
        $model->product_name=$request->post('product_name');
       
        if($request->hasfile('image'))
        {
            $file=$request->file('image');
            $extention=$file->getClientOriginalExtension();
            $filename=time().'.'.$extention;
            $file->move('img/', $filename);
            $model->image=$filename;
        }


        $model->description=$request->post('description');
        $model->status=1;
        $model->save();
        $request->session()->flash('message',$msg);
        return redirect('admin/product/banner/brand');
    }

    public function delete(Request $request,$id)
    {
        $model=Brand::find($id);
        $model->delete();
        $request->session()->flash('message','Brand Deleted');
        return redirect('admin/product/banner/brand');
    }

    public function status(Request $request,$status,$id)
    {
        $model=Brand::find($id);
        $model->status=$status;
        $model->save();
        $request->session()->flash('message','Brand status updated');
        return redirect('admin/product/banner/brand');
    }
}

<?php

namespace App\Http\Controllers\site_controller;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class SiteController extends Controller
{
    public function index(Request $req)
    {
        $result['home_categories']=DB::table('categories')
        ->where(['status'=>1])
        ->get();
        // echo "<pre>";
        // print_r($result['home_categories']);
        // die();
        return view('front_view.index',$result);
    }
}

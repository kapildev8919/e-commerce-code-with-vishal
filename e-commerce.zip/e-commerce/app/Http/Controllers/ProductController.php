<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;


class ProductController extends Controller
{
    public function index()
    {
        $result['data']=Product::all();
        return view('admin/product/product',$result);
    }
    
    public function manage_product(Request $request,$id='')
    {
        if($id>0){
            $arr= Product::where(['id'=>$id])->get();
            
            $result['Product_Name']=$arr['0']->Product_Name; 
            $result['url']=$arr['0']->url; 
            $result['Category']=$arr['0']->Category; 
            $result['id']=$arr['0']->id; 
        }
        else{
            $result['Product_Name']=''; 
            $result['url']=''; 
            $result['Category']=''; 
            $result['id']=''; 
        }
        
        return view('admin/product/manage_product',$result);
    }

    public function manage_product_process(Request $request)
    {
        // return $request->post();
        $request->validate([
            'Product_Name'=>'required',
            'url'=>'required',
            'Category'=>'required|unique:products,Category,'.$request->post('id'),
        ]);

       
        if($request->post('id')>0)
        {
            $model=Product::find($request->post('id'));
            $msg ="Product Updated";
        }
        else{
            $model=new Product();
            $msg ="Product Inserted";
            
        }
        
        $model->Product_Name=$request->server('Product_Name');
        $model->url=$request->server('url');
        $model->Category=$request->post('Category');
        $model->status=1;
        $model->save();
        $request->session()->flash('message',$msg);
        // return redirect('admin/product/banner/banner');
        return redirect('admin/product/product');
    }

    public function delete(Request $request,$id)
    {
        $model=Product::find($id);
        $model->delete();
        $request->session()->flash('message','Product Deleted');
        return redirect('admin/product/product');
    }

    public function status(Request $request,$status,$id)
    {
        $model=Product::find($id);
        $model->status=$status;
        $model->save();
        $request->session()->flash('message','Product status updated');
        return redirect('admin/product/product');
    }
}

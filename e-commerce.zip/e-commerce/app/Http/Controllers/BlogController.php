<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use Illuminate\Http\Request;

class BlogController extends Controller
{
    public function index()
    {
        $result['data']=Blog::all();
        return view('admin/product/banner/blog',$result);
    }
    
    public function manage_blog(Request $request,$id='')
    {
        if($id>0){
            $arr= Blog::where(['id'=>$id])->get();
            
            $result['Title']=$arr['0']->Title; 
            $result['image']=$arr['0']->image; 
            $result['description']=$arr['0']->description; 
            $result['status']=$arr['0']->status; 
            $result['id']=$arr['0']->id; 
        }
        else{
            $result['Title']=''; 
            $result['image']=''; 
            $result['description']=''; 
            $result['status']=''; 
            $result['id']=''; 
        }
        
        return view('admin/product/banner/manage_blog',$result);
    }

    public function manage_blog_process(Request $request)
    {
        // return $request->post();
        $request->validate([
            'Title'=>'required',
            'image'=>'required',
            'description'=>'required',
        ]);

       
        if($request->post('id')>0)
        {
            $model=Blog::find($request->post('id'));
            $msg ="Blog Updated";
        }
        else{
            $model=new Blog();
            $msg ="Blog Inserted";
        }
        $model->Title=$request->post('Title');
        
        if($request->hasfile('image'))
        {
            $file=$request->file('image');
            $extention=$file->getClientOriginalExtension();
            $filename=time().'.'.$extention;
            $file->move('img/', $filename);
            $model->image=$filename;
        }


        $model->description=$request->post('description');
        $model->status=1;
        $model->save();
        $request->session()->flash('message',$msg);
        return redirect('admin/product/banner/blog');
    }

    public function delete(Request $request,$id)
    {
        $model=Blog::find($id);
        $model->delete();
        $request->session()->flash('message','Blog Deleted');
        return redirect('admin/product/banner/blog');
    }

    public function status(Request $request,$status,$id)
    {
        $model=Blog::find($id);
        $model->status=$status;
        $model->save();
        $request->session()->flash('message','Blog status updated');
        return redirect('admin/product/banner/blog');
    }
}

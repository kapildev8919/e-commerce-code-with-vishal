<?php

namespace App\Http\Controllers;

use App\Models\Orderdetail;
use Illuminate\Http\Request;

class OrderdetailController extends Controller
{
    public function index()
    {
        $result['data']=Orderdetail::all();
        return view('admin/orderdetail',$result);
    }
    
    public function manage_orderdetail(Request $request,$id='')
    {
        if($id>0){
            $arr= Orderdetail::where(['id'=>$id])->get();
            
            $result['Customer_name']=$arr['0']->Customer_name; 
            $result['Address']=$arr['0']->Address; 
            $result['Mobile']=$arr['0']->Mobile; 
            $result['product_name']=$arr['0']->product_name; 
            $result['price']=$arr['0']->price; 
            $result['image']=$arr['0']->image; 
            $result['payment_method']=$arr['0']->payment_method;  
            $result['id']=$arr['0']->id; 
        }
        else{
            $result['Customer_name']=''; 
            $result['Address']=''; 
            $result['Mobile']=''; 
            $result['product_name']=''; 
            $result['price']=''; 
            $result['image']=''; 
            $result['payment_method']=''; 
            $result['id']=''; 
        }
        
        return view('admin/manage_orderdetail',$result);
    }

    public function manage_orderdetail_process(Request $request)
    {
        // return $request->post();
        $request->validate([
            'Customer_name'=>'required',
            'Address'=>'required',
            'Mobile'=>'required',
            'product_name'=>'required',
            'price'=>'required',
            'image'=>'required',
            'payment_method'=>'required',
        ]);

       
        if($request->post('id')>0)
        {
            $model=Orderdetail::find($request->post('id'));
            $msg ="Orderdetail Updated";
        }
        else{
            $model=new Orderdetail();
            $msg ="Orderdetail Inserted";
        }
        $model->Customer_name=$request->post('Customer_name');
        $model->Address=$request->post('Address');
        $model->Mobile=$request->post('Mobile');
        $model->product_name=$request->post('product_name');
        $model->price=$request->post('price');
        // $model->image=$request->file('image')->store('img');
        // $imageName = time().'.'.request()->image->getClientOriginalExtension();
        // request()->image->move(public_path('img'), $imageName);

        if($request->hasfile('image'))
        {
            $file=$request->file('image');
            $extention=$file->getClientOriginalExtension();
            $filename=time().'.'.$extention;
            $file->move('img/', $filename);
            $model->image=$filename;
        }
        $model->payment_method=$request->post('payment_method');
        $model->status=1;
        $model->save();
        $request->session()->flash('message',$msg);
        return redirect('admin/orderdetail');
    }

    public function delete(Request $request,$id)
    {
        $model=Orderdetail::find($id);
        $model->delete();
        $request->session()->flash('message','Orderdetail Deleted');
        return redirect('admin/orderdetail');
    }

    public function status(Request $request,$status,$id)
    {
        $model=Orderdetail::find($id);
        $model->status=$status;
        $model->save();
        $request->session()->flash('message','Orderdetail status updated');
        return redirect('admin/orderdetail');
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Footer;
use Illuminate\Http\Request;

class FooterController extends Controller
{
    public function index()
    {
        $result['data']=Footer::all();
        return view('admin/footer',$result);
    }
    
    public function manage_footer(Request $request,$id='')
    {
        if($id>0){
            $arr= Footer::where(['id'=>$id])->get();
            
            $result['menu']=$arr['0']->menu; 
            $result['discount']=$arr['0']->discount; 
            $result['offer']=$arr['0']->offer; 
            $result['site_map']=$arr['0']->site_map; 
            $result['suppliers']=$arr['0']->suppliers; 
            $result['faq']=$arr['0']->faq; 
            $result['address']=$arr['0']->address; 
            $result['mobile']=$arr['0']->mobile; 
            $result['email']=$arr['0']->email; 
            $result['links']=$arr['0']->links; 
            $result['id']=$arr['0']->id; 
        }
        else{
            $result['menu']=''; 
            $result['discount']=''; 
            $result['offer']=''; 
            $result['site_map']=''; 
            $result['suppliers']=''; 
            $result['faq']=''; 
            $result['address']=''; 
            $result['mobile']=''; 
            $result['email']=''; 
            $result['links']=''; 
            $result['id']=''; 
        }
        
        return view('admin/manage_footer',$result);
    }

    public function manage_footer_process(Request $request)
    {
        // return $request->post();
        $request->validate([
            'menu'=>'required',
            'discount'=>'required',
            'offer'=>'required',
            'site_map'=>'required',
            'suppliers'=>'required',
            'faq'=>'required',
            'address'=>'required',
            'mobile'=>'required',
            'email'=>'required',
            'links'=>'required',
        ]);

       
        if($request->post('id')>0)
        {
            $model=Footer::find($request->post('id'));
            $msg ="Footer Updated";
        }
        else{
            $model=new Footer();
            $msg ="Footer Inserted";
        }
        $model->menu=$request->post('menu');
        $model->discount=$request->post('discount');
        $model->offer=$request->post('offer');
        $model->site_map=$request->post('site_map');
        $model->suppliers=$request->post('suppliers');
        $model->faq=$request->post('faq');
        $model->address=$request->post('address');
        $model->mobile=$request->post('mobile');
        $model->email=$request->post('email');
        $model->links=$request->post('links');
        // $model->status=1;
        $model->save();
        $request->session()->flash('message',$msg);
        return redirect('admin/footer');
    }

    public function delete(Request $request,$id)
    {
        $model=Footer::find($id);
        $model->delete();
        $request->session()->flash('message','Footer Deleted');
        return redirect('admin/footer');
    }

    public function status(Request $request,$status,$id)
    {
        $model=Footer::find($id);
        $model->status=$status;
        $model->save();
        $request->session()->flash('message','Footer status updated');
        return redirect('admin/footer');
    }
}
